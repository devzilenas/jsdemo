<?
if (isset($_POST['start'])) {
	unset($_SESSION['universe']);
	unset($_SESSION['vaizduoklis']);
}

if (empty($_SESSION['universe'])) { 
	$universe = new Universe(); 
	$universe->start(16);
	$_SESSION['universe'] = $universe;
} else {//advance
	$universe = $_SESSION['universe'];
	$universe->step();
	$_SESSION['universe'] = $universe;
} 

if (isset($_SESSION['vaizduoklis'])) {
	$vaizduoklis = $_SESSION['vaizduoklis'];
} else {
	$vaizduoklis = new Vaizduoklis();
	$vaizduoklis->setBakterijosDydis(10);
	$_SESSION['vaizduoklis'] = $vaizduoklis;
} 

$world = $universe->world();

//
$stale = $universe->isStale();
$age   = $universe->age();
// 
?>
