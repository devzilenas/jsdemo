<?
include 'vaizduoklis.class.php';
include 'life.class.php';

session_start();
include 'request.inc.php';

?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Bakteriju pasaulis :: Metai <?= $age; ?></title>
		<? if (!$stale) { ?>
			<meta http-equiv="refresh" content="0">
		<?  } ?>
		<style type="text/css">
			body {font-family:monospace}
		</style>
	</head>
<body>
<? if ($stale) { ?>
<p>
<form method="post">
	<input type="submit" name="start" value="Pradėti" />
</form>
</p>
<? } ?>
<h1>Metai: <?= $age; ?></h2>
<?
echo '<img alt="Bakteriju pasaulis. Metai '.$age.'" title="Bakteriju pasaulis. Metai '.$age.'" src="data:image/png;base64,'.$vaizduoklis->toImage64($world, TRUE).'"/>';
 ?>

<p>2012 m. <a href="mailto:mzilenas@gmail.com">Marius Žilėnas</a></p>
</body>
</html>
