<?
class Vaizduoklis { 

	public $bakterijosDydis;

	public function bakterijosDydis() {
		return $this->bakterijosDydis;
	}

	public function setBakterijosDydis($bd) {
		$this->bakterijosDydis = $bd;
	}

	public function to_s($world) {
		$out_y = array();
		for($y = 0; $y < $world->size_y; $y++) {
			$out_x = array();
			for ($x = 0; $x < $world->size_x; $x++) {
				$world->isBAt($x,$y) ? $out_x[] = '@' : $out_x[] = '.';
			}
			$out_y[] = '|'.join(" ", $out_x).'|';
		}
		$out = '&nbsp;'.str_repeat('-', $world->size_x*2-1).'<br />'.implode('<br />', $out_y).'<br />'.'&nbsp;'.str_repeat('-', $world->size_x*2-1);

		return $out;
	}

	public function toSTable($world) {
		$maxAge = $world->maxAge(); 
		$out = '';
		for($y = 0; $y < $world->size_y; $y++) {
			$out_x = '';
			for ($x = 0; $x < $world->size_x; $x++) {
				$color = 0;
				if ($world->isBAt($x,$y)) {
					$val = '&bull;';
					if ($maxAge > 0 ) {
						$color = (int)($world->at($x,$y)->age()/$maxAge*255);
					}
				} else {
					$val = '&nbsp;';
				}
				$out_x .= '<td style="color:#'.dechex($color).'0000">'.$val.'</td>';
			}
			$out .= '<tr>'.$out_x.'</tr>';
		} 
		$out = '<table>'.$out.'</table>'; 
		return $out; 
	}

	public function toImage64($world, $grid = FALSE) {
		$grid ? $offset = 1 : $offset = 0;

		$im = imagecreatetruecolor( $world->size_x*$this->bakterijosDydis+$offset, $world->size_y*$this->bakterijosDydis+$offset) or die("Paveiskliukas nesukurtas!");
		$bakterijaColor = imagecolorallocate($im, 0, 255, 0);
		$backColor      = imagecolorallocate($im, 0, 0, 0);
		$color          = $backColor;

		if ($grid) {
			$gridColor = imagecolorallocate($im, 255, 0 , 0);
			//nupiesk groteles 
			for($y = 0; $y <= $world->size_y; $y++) {
				imageline($im, 0,$y*$this->bakterijosDydis, $world->size_x*$this->bakterijosDydis, $y*$this->bakterijosDydis, $gridColor);
			}
			for($x = 0; $x <= $world->size_x; $x++) {
				imageline($im, $x*$this->bakterijosDydis, 0, $x*$this->bakterijosDydis, $world->size_y*$this->bakterijosDydis, $gridColor);
			}
		}

		for($y = 0; $y < $world->size_y; $y++) {
			for ($x = 0; $x < $world->size_x; $x++) {
				$world->isBAt($x,$y) ? $color = $bakterijaColor : $color = $backColor;

				if ($this->bakterijosDydis == 1) {
					imagesetpixel($im, $x, $y, $color);
				} else {
					imagefilledrectangle($im, $x*$this->bakterijosDydis+$offset, $y*$this->bakterijosDydis+$offset, ($x+1)*$this->bakterijosDydis-$offset, ($y+1)*$this->bakterijosDydis-$offset, $color);
				}
			}
		}
		ob_start();
		imagepng($im);
		$image_data = ob_get_contents();
		ob_end_clean();
		imagedestroy($im);
		return base64_encode($image_data);
	}
}
?>
