<?
class Cell {

	private $age = 0;

	public function age() {
		return $this->age;
	}

	public function advance() {
		$this->age++;
	}

}

class Universe { 
	private $binaryCodes = array(); 
	private $world       = NULL;
	private $age         = 0;

	public function world() {
		return $this->world;
	}
	public function age() {
		return $this->age;
	}
	
	public function size() {
		return $this->world->size_x;
	}

	public function start($size=16) { 
		$this->world = new World($size);
		$this->world->randomize(); 
		$this->fp();
	}

	public function step() { 
		!$this->world ? $this->start() : NULL ;
		$this->world->advance();
		$this->age++;
		$this->fp();
	}

	public function isStale() {
		return $this->sustojo() || $this->mirksi();
	}

	private function binaryCode() {
		$str = '';
		for($y = 0; $y < $this->world->size_y; $y++) {
			for ($x = 0; $x < $this->world->size_x; $x++) {
				$this->world->isBAt($x,$y) ? $str .= '1' : $str .= '0';
			}
		}
		return $str;
	}

	private function fp() {//pasaulio "pirsto atspaudas"
		$this->binaryCodes[] = md5($this->binaryCode());
		while (count($this->binaryCodes) > 3) array_shift($this->binaryCodes);
	}

	private function sustojo() {
		$count = count($this->binaryCodes);
		return $count > 1 && $this->binaryCodes[$count-1] == $this->binaryCodes[$count-2];
	}

	private function mirksi() {
		$count = count($this->binaryCodes);
		return $count > 2 && $this->binaryCodes[$count-1] == $this->binaryCodes[$count-3]; 
	}

} 

class World {
	public  $size_x;
	public  $size_y; 
	public  $age = 0;
	public  $matrix      = array();
	private $new_matrix  = array(); 

	public function size() {
		return $this->size_x*$this->size_y;
	}
	
	private static function mod($a,$b) {
		return ($b + ($a % $b)) % $b;
	}

	public function __construct($size) {
		$this->size_x = $size;
		$this->size_y = $size;
	}

	private function i($x,$y) {//koordinates x,y bakterijai
		return self::mod($y, $this->size_y)*$this->size_x + self::mod($x, $this->size_x);
	}

	public function isBAt($x,$y) {//patikrina ar yra bakterija x,y koordinatese
		return isset($this->matrix[$this->i($x, $y)]);
	}

	public function at($x,$y) {//paduoda bakterija x,y koordinatese
		return $this->isBAt($x,$y) ? $this->matrix[$this->i($x,$y)] : NULL;
	}

	private function putAt($x,$y,$cell) {
		$this->matrix[$this->i($x,$y)] = $cell;
	}

	private function removeAt($x,$y) {
		unset($this->matrix[$this->i($x,$y)]);
	}

	private function neighborsCount($x,$y) {
		$nc = 0;
		if ($this->isBAt($x, $y - 1)) { //N
			$nc++;
		}
		if ($this->isBAt($x + 1, $y - 1)) {//NE
			$nc++;
		}
		if ($this->isBAt($x+1, $y)) {//E
			$nc++;
		}
		if ($this->isBAt($x+1, $y+1)){//ES
			$nc++;
		}
		if ($this->isBAt($x, $y+1)) {//S
			$nc++;
		}
		if ($this->isBAt($x-1, $y+1)) {//SW
			$nc++;
		}
		if ($this->isBAt($x-1, $y)) {//W
			$nc++;
		}
		if ($this->isBAt($x-1,$y-1)) {//NW
			$nc++;
		}
		return $nc;
	}

	public function advance() {
		$this->new_matrix = array();
		for($y = 0; $y < $this->size_y; $y++) {
			for ($x = 0; $x < $this->size_x; $x++) {
				$nc   = $this->neighborsCount($x,$y); 
				$live = $this->isBAt($x,$y);
				if ($live) { //cell is occupied
					if ($nc < 2) {
						$live = FALSE;
					} elseif ($nc == 2 || $nc == 3) {
						//leave with no change
						$live = TRUE;
					} elseif ($nc > 3) { 
						$live = FALSE;
					}
				} else {//cell is empty
					if ($nc == 3) {
						$live = TRUE;
					}
				}
				$this->new_matrix[$this->i($x, $y)] = $live ? 1 : 0;
			}
		}

		for($y = 0; $y < $this->size_y; $y++) {
			for ($x = 0; $x < $this->size_x; $x++) {
				if ($this->new_matrix[$this->i($x,$y)] == 1) {
					if ($this->isBAt($x,$y)) {
						$this->at($x,$y)->advance();
					} else {
						$this->putAt($x, $y, new Cell());
					}
				} else {
					if ($this->isBAt($x,$y)) {
						$this->removeAt($x,$y);
					}
				}
			}
		}  

		$this->age++;
	} 

	public function randomize() {
		for($y = 0; $y < $this->size_y; $y++) {
			for ($x = 0; $x < $this->size_x; $x++) {
				if (mt_rand(0, getrandmax())/getrandmax() > 0.5) {
					$this->putAt($x,$y, new Cell());
				}
			}
		}
	}

	public function maxAge() {
		$maxAge = 0;
		for($y = 0; $y < $this->size_y; $y++) {
			for ($x = 0; $x < $this->size_x; $x++) {
				if ($this->isBAt($x,$y) && $this->at($x,$y)->age() > $maxAge) {
					$maxAge = $this->at($x,$y)->age();
				}
			}
		}
		return $maxAge;
	}

} 
?>
