<?
include 'vaizduoklis.class.php';
include 'life.class.php';
include '../dienoslapas/class/form.class.php';

session_start();
include 'request.inc.php';

?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Bakteriju pasaulis PIPI:: Metai <?= $universe->age(); ?></title>
		<? if (!$stale && empty($_POST['stop'])) { ?>
			<meta http-equiv="refresh" content="0">
		<?  } ?>
		<style type="text/css">
			body {font-family:monospace}
		</style>
	</head>
<body>
<p>
<form method="post">
	<input type="hidden" name="reset" value="reset" >
	<select id="bakterijosDydis" name="bakterijosDydis">
		<?= Form::options(array('1'=>'1', '10'=>'10', '20'=>'20'), $bakterijosDydis); ?>
	</select><label for="bakterijosDydis">Bakterijos dydis</label><br/>
	<select id="size" name="size">
		<?= Form::options(array('16'=>'16', '32'=>'32', '40'=>'40'), $size); ?>
	</select> <label for="size">Pasaulio dydis</label><br />
	<input type="radio" name="display" id="display1" value="1" <?= $display===1 ? 'checked':''; ?> /><label for="display1">Tekstinis</label><br />
	<input type="radio" name="display" id="display2" value="2" <?= $display===2 ? 'checked':''; ?> /><label for="display2">Tekstinis su spalvomis</label><br />
	<input type="radio" name="display" id="display3" value="3" <?= $display===3 ? 'checked':''; ?> /><label for="display3">Grafinis</label><br />
	<input type="submit" name="start" value="Pradėti" />
</form>
</p>
<form method="post">
	<input type="submit" value="Sustabdyti" name="stop" />
	<input type="submit" value="Pauze" name="pause" /> 
	<input type="submit" value="Next" name="Advance" /> 
</form>
<h1>Metai: <?= $age; ?></h2>
<?
if ($display === 1) {
	echo $vaizduoklis->to_s($world);
} elseif ($display === 2) {
	echo $vaizduoklis->toSTable($world);
} elseif ($display === 3) {
	echo '<img alt="Bakteriju pasaulis. Metai '.$age.'" title="Bakteriju pasaulis. Metai '.$age.'" src="data:image/png;base64,'.$vaizduoklis->toImage64($world, TRUE).'"/>';
} ?>

<p>2012 m. <a href="mailto:mzilenas@gmail.com">Marius Žilėnas</a></p>
</body>
</html>
