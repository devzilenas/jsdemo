<?
// Atvaizdavimo metodo parinkimas
if (isset($_POST['display'])) {
	$_SESSION['display'] = (int)$_POST['display'];
}
if (isset($_SESSION['display'])) {
	$display = $_SESSION['display'];
} else {
	$display = 1;
}
if (!($display === 1 || $display === 2 || $display === 3)) {
	$display = 1;
}

if (isset($_POST['reset'])) {
	unset($_SESSION['universe']);
	unset($_SESSION['vaizduoklis']);
}

if (empty($_SESSION['universe'])) { 
	$universe = new Universe(); 
	if (!empty($_POST['size']) && is_numeric($_POST['size'])) { 
		$universe->start($_POST['size']);
	} else {
		$universe->start();
	} 
	$_SESSION['universe'] = $universe;
} else {//advance
	$universe = $_SESSION['universe'];
	$universe->step();
	$_SESSION['universe'] = $universe;
} 

if (isset($_SESSION['vaizduoklis'])) {
	$vaizduoklis = $_SESSION['vaizduoklis'];
} else {
	$vaizduoklis = new Vaizduoklis();
	if (isset($_POST['bakterijosDydis'])) {
		$vaizduoklis->setBakterijosDydis($_POST['bakterijosDydis']);
	}
	$_SESSION['vaizduoklis'] = $vaizduoklis;
} 

$world       = $universe->world();

//
$stale           = $universe->isStale();
$age             = $universe->age();
$bakterijosDydis = $vaizduoklis->bakterijosDydis();
$size            = $universe->size();
// 
?>
